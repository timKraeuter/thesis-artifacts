/* (c) https://github.com/MontiCore/monticore */
package crossing;

component Crossing {

  CarTrafficLight ctl;
  PedestrianTrafficLight ptl;

  ctl.signal -> ptl.signal;
}
