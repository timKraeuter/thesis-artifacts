/* (c) https://github.com/MontiCore/monticore */
package crossing;

import crossing.Datatypes.*;

component PedestrianTrafficLight {

  port
    <<sync>> in Signal signal;

  automaton {
      initial state Green;

      state Red;

      Red -> Green [signal == Signal.GREEN];

      Green -> Red [signal == Signal.RED];
    }
}
